import socket
import time
import thread 
import sys
import select
client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(("127.0.0.1",56673))
ans = "w"
def timer():
	global ans
	ans = raw_input("enter your answer A) B) C) D) and press enter\n")
	return ans
	
while True:
	size=client.recv(100)
	if size == "no":
		client.close()
		break
	size = int(size)
	client.send("yes")
	data = client.recv(size)
	print(data)
	ans = thread.start_new_thread(timer,())
	ans = str(ans)
	time.sleep(5)	
	client.send(ans)
	resp = client.recv(100)
	print(resp)
	client.send("yes")
